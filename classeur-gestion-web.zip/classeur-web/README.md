# 📒 Classeur de Gestion Financière — Version Web

Application web de gestion financière déployable en ligne.
Accessible depuis n'importe quel appareil (PC, téléphone, tablette).

## Fonctionnalités

- ✅ Tableau de bord avec KPIs et graphiques
- ✅ Gestion des services rendus
- ✅ Gestion des biens vendus
- ✅ Suivi des dépenses & charges
- ✅ Gestion du stock (alertes stock faible)
- ✅ États financiers (livre journal, analyse mensuelle)
- ✅ Caisse & Budget mensuel
- ✅ Export PDF (rapport financier + facture)
- ✅ Paramètres entreprise

---

## 🚀 Déploiement en ligne (GRATUIT) — Render.com

### Étape 1 — Préparer le code

1. Créez un compte sur [GitHub](https://github.com) (gratuit)
2. Créez un nouveau dépôt GitHub (ex: `classeur-gestion`)
3. Uploadez tous les fichiers de ce dossier dans le dépôt

### Étape 2 — Déployer sur Render

1. Allez sur [render.com](https://render.com) → créez un compte gratuit
2. Cliquez **"New +"** → **"Web Service"**
3. Connectez votre dépôt GitHub
4. Remplissez les champs :
   - **Name** : `classeur-gestion` (ou ce que vous voulez)
   - **Environment** : Python 3
   - **Build Command** : `pip install -r requirements.txt`
   - **Start Command** : `gunicorn app:app --bind 0.0.0.0:$PORT --workers 1`
5. Cliquez **"Create Web Service"**
6. Attendez 2-3 minutes → votre URL sera : `https://classeur-gestion.onrender.com`

### Étape 3 — Disque persistant (IMPORTANT pour ne pas perdre les données)

Sur Render (plan gratuit), les fichiers sont effacés à chaque redémarrage.
Pour conserver vos données :

**Option A — Render Disk (payant, $0.25/mois)**
- Dans votre service Render → **"Disks"** → **"Add Disk"**
- Mount Path : `/data`
- Ajoutez dans les variables d'environnement :
  - `DATA_PATH` = `/data/data.json`

**Option B — Export/Import manuel**
- Exportez vos données en PDF régulièrement
- Les données sont sauvegardées en JSON dans le dossier du projet

---

## 🖥️ Lancer en local (sur votre ordinateur)

```bash
# 1. Installer Python 3.9+
# 2. Ouvrir un terminal dans le dossier classeur-web/
# 3. Installer les dépendances
pip install -r requirements.txt

# 4. Lancer l'application
python app.py

# 5. Ouvrir dans le navigateur
# → http://localhost:5000
```

---

## 📱 Accès depuis un téléphone (réseau local)

Si vous lancez l'app sur votre PC et voulez y accéder depuis votre téléphone
(sur le même WiFi) :

```bash
# Lancer avec l'IP locale
python app.py
# Puis sur votre téléphone, allez sur : http://192.168.X.X:5000
# (remplacez par l'IP de votre PC)
```

---

## 🔧 Structure des fichiers

```
classeur-web/
├── app.py              ← Application Flask (backend)
├── requirements.txt    ← Dépendances Python
├── Procfile            ← Configuration serveur production
├── README.md           ← Ce fichier
├── data.json           ← Données (créé automatiquement)
└── templates/
    └── index.html      ← Interface web (frontend)
```

---

## ❓ Questions fréquentes

**Q: Mes données sont-elles sécurisées ?**
R: Les données sont stockées en JSON sur le serveur. Pour un usage professionnel,
   ajoutez un mot de passe (voir variable d'environnement `APP_PASSWORD`).

**Q: Puis-je utiliser une vraie base de données ?**
R: Oui, vous pouvez remplacer le fichier JSON par SQLite ou PostgreSQL
   en modifiant les fonctions `load_data()` et `save_data()` dans `app.py`.

**Q: L'application est-elle responsive (mobile) ?**
R: Oui, elle fonctionne sur téléphone et tablette avec Bootstrap 5.
